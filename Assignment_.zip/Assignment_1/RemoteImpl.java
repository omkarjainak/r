import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

public class RemoteImpl extends UnicastRemoteObject implements RemoteInterface {
    public RemoteImpl() throws RemoteException {
        super();
    }

    @Override
    public synchronized String sayHello(String name) throws RemoteException {
        System.out.println("Serving client: " + name + " - " + Thread.currentThread().getName());
        return "Hello, " + name + "! This is from server.";
    }
}
